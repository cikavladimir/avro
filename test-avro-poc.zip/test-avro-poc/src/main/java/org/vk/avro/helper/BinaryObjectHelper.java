/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.vk.avro.helper;

import java.io.IOException;
import java.util.AbstractMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;
import org.apache.avro.Schema;
import org.apache.avro.file.DataFileStream;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericFixed;
import org.apache.avro.generic.GenericRecord;
import org.apache.ignite.Ignite;
import org.apache.ignite.binary.BinaryObject;
import org.apache.ignite.binary.BinaryObjectBuilder;
import org.apache.ignite.cache.affinity.AffinityKey;

public class BinaryObjectHelper {
    private static final String ID_SUFFIX = "_id";

    private static final AtomicLong ID_GEN = new AtomicLong();

    private final Ignite ignite;

    private GenericRecord record;

    private Map<AffinityKey<Long>, BinaryObjectBuilder> builders;

    private Long affinityKey;

    public BinaryObjectHelper(Ignite ignite) {
        this.ignite = ignite;
    }

    public Map<AffinityKey<Long>, BinaryObject> binaryObjects(Schema schema, String path) throws IOException {
        Map<AffinityKey<Long>, BinaryObject> binaryObjects = new HashMap<>();

        Iterator<GenericRecord> stream = new DataFileStream<>(
            BinaryObjectHelper.class.getClassLoader().getResourceAsStream(path),
            new GenericDatumReader<>(schema));

        while (stream.hasNext()) {
            record = stream.next();

            builders = new HashMap<>();

            binaryObjects.putAll(processSchema(schema, null));
        }

        return binaryObjects;
    }

    private Map<AffinityKey<Long>, BinaryObject> processSchema(Schema schema, Id parentId) {
        assert schema.getType() == Schema.Type.RECORD;

        BinaryObjectBuilder builder = ignite.binary().builder(schema.getName());

        String idFieldName = schema.getName() + ID_SUFFIX;
        Long id = ID_GEN.getAndIncrement();

        builder.setField(idFieldName, id);

        if (parentId != null)
            builder.setField(parentId.fieldName, parentId.fieldValue);

        builders.put(new AffinityKey<>(id, affinityKey), builder);

        if (affinityKey == null)
            affinityKey = id;

        processFields(schema, builder, new Id(idFieldName, id));

        return builders.entrySet().stream().map(e -> new AbstractMap.SimpleEntry<>(e.getKey(), e.getValue().build())).
            collect(Collectors.toMap(AbstractMap.SimpleEntry::getKey, AbstractMap.SimpleEntry::getValue));
    }

    private void processFields(Schema schema, BinaryObjectBuilder builder, Id id) {
        assert schema.getType() == Schema.Type.RECORD;

        for (Schema.Field field : schema.getFields())
            processField(field.name(), field.schema(), builder, id);
    }

    private void processField(String fieldName, Schema fieldSchema, BinaryObjectBuilder builder, Id id) {
        switch (fieldSchema.getType()) {
            case RECORD: {
                GenericRecord parentRecord = record;

                record = (GenericRecord)record.get(fieldName);

                processFields(fieldSchema, builder, id);

                record = parentRecord;

                break;
            }

            case UNION: {
                List<Schema> unionTypes = fieldSchema.getTypes();

                if (unionTypes.size() == 2 && unionTypes.get(0).getType() == Schema.Type.NULL)
                    processField(fieldName, unionTypes.get(1), builder, id);
                else
                    throw new IllegalStateException("Unsupported UNION types: " + unionTypes);

                break;
            }

            case ARRAY: {
                Schema elementSchema = fieldSchema.getElementType();

                if (elementSchema.getType() == Schema.Type.RECORD) {
                    Iterable<GenericRecord> array = (Iterable<GenericRecord>)record.get(fieldName);

                    for (GenericRecord element : array) {
                        GenericRecord parentRecord = record;

                        record = element;

                        processSchema(elementSchema, id);

                        record = parentRecord;
                    }
                }
                else
                    builder.setField(fieldName, record.get(fieldName));

                break;
            }

            case FIXED: {
                GenericFixed fieldValue = (GenericFixed)record.get(fieldName);

                builder.setField(fieldName, fieldValue != null ? fieldValue.bytes() : null);

                break;
            }

            case STRING: {
                Object fieldValue = record.get(fieldName);

                builder.setField(fieldName, fieldValue != null ? fieldValue.toString() : null);

                break;
            }

            case MAP:
            case ENUM:
            case BYTES:
            case INT:
            case LONG:
            case FLOAT:
            case DOUBLE:
            case BOOLEAN:
                builder.setField(fieldName, record.get(fieldName));

                break;

            case NULL:
                break;
        }
    }

    private static class Id {
        private String fieldName;

        private Long fieldValue;

        private Id(String fieldName, Long fieldValue) {
            this.fieldName = fieldName;
            this.fieldValue = fieldValue;
        }
    }
}
