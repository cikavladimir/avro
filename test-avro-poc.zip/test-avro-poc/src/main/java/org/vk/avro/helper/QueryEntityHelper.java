/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.vk.avro.helper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.apache.avro.Schema;
import org.apache.ignite.cache.QueryEntity;
import org.apache.ignite.cache.affinity.AffinityKey;

public class QueryEntityHelper {
    private static final String ID_SUFFIX = "_id";

    private Collection<QueryEntity> entities;

    public Collection<QueryEntity> queryEntities(Schema schema) {
        entities = new ArrayList<>();

        return processSchema(schema, null);
    }

    private Collection<QueryEntity> processSchema(Schema schema, String parentId) {
        assert schema.getType() == Schema.Type.RECORD;

        QueryEntity entity = new QueryEntity();

        entity.setKeyType(AffinityKey.class.getName());
        entity.setValueType(schema.getName());

        entity.addQueryField(schema.getName() + ID_SUFFIX, Long.class.getName(), null);

        if (parentId != null)
            entity.addQueryField(parentId, Long.class.getName(), null);

        entities.add(entity);

        processFields(schema, entity);

        return entities;
    }

    private void processFields(Schema schema, QueryEntity entity) {
        assert schema.getType() == Schema.Type.RECORD;

        for (Schema.Field field : schema.getFields())
            processField(field.name(), field.schema(), entity);
    }

    private void processField(String fieldName, Schema fieldSchema, QueryEntity entity) {
        switch (fieldSchema.getType()) {
            case RECORD:
                processFields(fieldSchema, entity);

                break;

            case UNION:
                List<Schema> unionTypes = fieldSchema.getTypes();

                if (unionTypes.size() == 2 && unionTypes.get(0).getType() == Schema.Type.NULL)
                    processField(fieldName, unionTypes.get(1), entity);
                else
                    throw new IllegalStateException("Unsupported UNION types: " + unionTypes);

                break;

            case ARRAY:
                Schema elementSchema = fieldSchema.getElementType();

                if (elementSchema.getType() == Schema.Type.RECORD)
                    processSchema(elementSchema, entity.getValueType() + ID_SUFFIX);
                else
                    entity.addQueryField(fieldName, Object.class.getName(), null);

                break;

            case MAP:
                entity.addQueryField(fieldName, Object.class.getName(), null);

                break;

            case ENUM:
                entity.addQueryField(fieldName, Object.class.getName(), null);

                break;

            case FIXED:
                entity.addQueryField(fieldName, byte[].class.getName(), null);

                break;

            case STRING:
                entity.addQueryField(fieldName, String.class.getName(), null);

                break;

            case BYTES:
                entity.addQueryField(fieldName, byte[].class.getName(), null);

                break;

            case INT:
                entity.addQueryField(fieldName, Integer.class.getName(), null);

                break;

            case LONG:
                entity.addQueryField(fieldName, Long.class.getName(), null);

                break;

            case FLOAT:
                entity.addQueryField(fieldName, Float.class.getName(), null);

                break;

            case DOUBLE:
                entity.addQueryField(fieldName, Double.class.getName(), null);

                break;

            case BOOLEAN:
                entity.addQueryField(fieldName, Boolean.class.getName(), null);

                break;

            case NULL:
                break;
        }
    }
}
