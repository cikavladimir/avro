/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.vk.avro;

import java.util.List;
import org.apache.avro.Schema;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.Ignition;
import org.apache.ignite.binary.BinaryObject;
import org.apache.ignite.cache.affinity.AffinityKey;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.configuration.CacheConfiguration;
import org.vk.avro.helper.BinaryObjectHelper;
import org.vk.avro.helper.QueryEntityHelper;

public class App {
    public static void main(String[] args) throws Exception {
        Ignite ignite = Ignition.start();

        QueryEntityHelper queryEntityHelper = new QueryEntityHelper();
        BinaryObjectHelper binaryObjectHelper = new BinaryObjectHelper(ignite);

        Schema schema = new Schema.Parser().parse(App.class.getClassLoader().getResourceAsStream("sample.avsc"));

        CacheConfiguration<AffinityKey<Long>, BinaryObject> cfg = new CacheConfiguration<>("test-cache");

        cfg.setQueryEntities(queryEntityHelper.queryEntities(schema));

        IgniteCache<AffinityKey<Long>, BinaryObject> cache = ignite.createCache(cfg).withKeepBinary();

        cache.putAll(binaryObjectHelper.binaryObjects(schema, "sample.avro"));

        System.out.println("Cache size: " + cache.size());

        List<List<?>> res = cache.query(new SqlFieldsQuery(
            "SELECT e.eventPrefix, e.providerID, d.cardholderBillingAmount, i.name, t.id " +
            "FROM EnterpriseEvent e, domainSpecificPayloadSchema d, items_5 i, token_17 t " +
            "WHERE d.EnterpriseEvent_id = e.EnterpriseEvent_id " +
            "AND i.domainSpecificPayloadSchema_id = d.domainSpecificPayloadSchema_id " +
            "AND t.domainSpecificPayloadSchema_id = d.domainSpecificPayloadSchema_id"
        )).getAll();

        System.out.println("Query result: ");

        for (List<?> row : res)
            System.out.println("  " + row);
    }
}
