CapitalOne POC
--------------

This project demonstrates how to convert Avro schema to Ignite schema, and then Avro messages to Ignite messages.
Goal is to create a generic mechanism for storing/indexing/querying object coming from Avro in Ignite cluster.

Three Java classes are included:
* QueryEntityHelper - traverses Avro schema and creates set of QueryEntity objects that define Ignite schema.
* BinaryObjectHelper - converts Avro message into a set of BinaryObjects instances to be saved in Ignite cache.
* App - simple test that starts an Ignite node, creates cache based on sample Avro schema, saves sample message in
        cache and executes an SQL query.
